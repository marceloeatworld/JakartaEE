package com.models;

import java.util.HashMap;
import java.util.Map;

public class ListePersonne {
    private Map<String, Personne> liste;

    public ListePersonne() {
        liste = new HashMap<>();

        // Adding dummy users
        liste.put("user1", new Personne("user1", "Nom1", "Prenom1", "0123456789"));
        liste.put("user2", new Personne("user2", "Nom2", "Prenom2", "1234567890"));
        liste.put("user3", new Personne("user3", "Nom3", "Prenom3", "2345678901"));
    }

    public Personne getPersonne(String user) {
        Personne personne = liste.get(user);
        return personne != null ? new Personne(personne) : null;
    }

    public void addPersonne(Personne personne) {
        liste.put(personne.getUser(), personne);
    }

    public Map<String, Personne> getListe() {
        return new HashMap<>(liste);
    }
}
