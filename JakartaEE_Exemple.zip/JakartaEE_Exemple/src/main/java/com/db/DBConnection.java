package com.db;

import java.sql.*;

public class DBConnection {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/jakarta?useSSL=false";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Benali89";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
    }
}
