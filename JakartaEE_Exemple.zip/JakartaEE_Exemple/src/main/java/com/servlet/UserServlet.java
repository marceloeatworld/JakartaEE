package com.servlet;

import com.models.ListePersonne;
import com.models.Personne;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet("/user")
public class UserServlet extends HttpServlet {
    private ListePersonne listePersonne;

    public void init() {
        listePersonne = new ListePersonne();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("saisie".equals(action)) {
            String user = request.getParameter("user");
            Personne personne = listePersonne.getPersonne(user);

            if (personne == null) {
                request.setAttribute("user", user);
                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/saisieInfos.jsp");
                dispatcher.forward(request, response);
            } else {
                request.setAttribute("personne", personne);
                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/detailsPersonne.jsp");
                dispatcher.forward(request, response);
            }
        } else if ("add".equals(action)) {
            String user = request.getParameter("user");
            String nom = request.getParameter("nom");
            String prenom = request.getParameter("prenom");
            String telephone = request.getParameter("telephone");

            Personne personne = new Personne(user, nom, prenom, telephone);
            listePersonne.addPersonne(personne);

            request.setAttribute("listePersonne", listePersonne);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/listePersonne.jsp");
            dispatcher.forward(request, response);
        }
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("list".equals(action)) {
            request.setAttribute("listePersonne", listePersonne);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/listePersonne.jsp");
            dispatcher.forward(request, response);
        } else if ("saisie".equals(action)) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/saisieUser.jsp");
            dispatcher.forward(request, response);
        }
    }
}
